package com.example.project_two_andremiranda;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

@Entity(tableName = "inventory_items")
public class InventoryItem {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    private String name;

    private int quantity;

    // Required empty constructor for Room and manual creation
    public InventoryItem() {
        // Room and AddItemActivity need this
    }

    // Main constructor
    @Ignore
    public InventoryItem(@NonNull String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    // Getters
    public int getId() { return id; }
    @NonNull public String getName() { return name; }
    public int getQuantity() { return quantity; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setName(@NonNull String name) { this.name = name; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    // DiffUtil support
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof InventoryItem)) return false;

        InventoryItem other = (InventoryItem) obj;
        return id == other.id &&
                quantity == other.quantity &&
                name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return (id * 31) + name.hashCode() + quantity;
    }
}