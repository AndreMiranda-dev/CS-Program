package com.example.project_two_andremiranda;

import android.content.Context;
import android.telephony.SmsManager;

import androidx.annotation.NonNull;

public class NotificationsRepository {

    private static final String PREFS_NAME = "notification_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    private final Context context;

    public NotificationsRepository(@NonNull Context context) {
        this.context = context.getApplicationContext();
    }

    // Save SMS enabled/disabled preference
    public void setSmsEnabled(boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SMS_ENABLED, enabled)
                .apply();
    }

    // Read SMS enabled/disabled preference
    public boolean isSmsEnabled() {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SMS_ENABLED, false);
    }

    // Send SMS using system SmsManager
    public boolean sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );
            return true;
        } catch (Exception e) {
            e.printStackTrace(); // Optional debugging
            return false;
        }
    }
}