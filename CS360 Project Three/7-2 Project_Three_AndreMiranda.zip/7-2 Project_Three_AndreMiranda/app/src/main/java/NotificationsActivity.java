package com.example.project_two_andremiranda;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class NotificationsActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 1001;

    private Button buttonRequestPermission;
    private Button buttonTestSms;
    private Button buttonSavePhone;
    private TextView textStatus;
    private Switch switchEnableSms;
    private EditText editPhoneNumber;
    private ImageView imageValidPhone;

    private NotificationsViewModel notificationsViewModel;

    private boolean isFormatting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        initViews();
        initViewModel();
        loadSavedPhoneNumber();
        setupPhoneFormatting();
        setupListeners();

        // Ensure permission status is correct on screen load
        updateStatusText();
    }

    private void initViews() {
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonTestSms = findViewById(R.id.buttonSimulateNotification);
        textStatus = findViewById(R.id.textPermissionStatus);
        switchEnableSms = findViewById(R.id.switchEnableSms);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSavePhone = findViewById(R.id.buttonSavePhone);
        imageValidPhone = findViewById(R.id.imageValidPhone);
    }

    private void initViewModel() {
        notificationsViewModel = new ViewModelProvider(this).get(NotificationsViewModel.class);
        switchEnableSms.setChecked(notificationsViewModel.isSmsEnabled());
    }

    private void loadSavedPhoneNumber() {
        SharedPreferences prefs = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        String savedNumber = prefs.getString("phone_number", "");

        String formatted = formatPhone(savedNumber);
        editPhoneNumber.setText(formatted);

        boolean valid = savedNumber.matches("\\d{10}");
        imageValidPhone.setVisibility(valid ? ImageView.VISIBLE : ImageView.GONE);
        buttonSavePhone.setEnabled(valid);
    }

    private void setupPhoneFormatting() {
        editPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;

                isFormatting = true;

                String digits = s.toString().replaceAll("\\D", "");
                String formatted = formatPhone(digits);

                editPhoneNumber.setText(formatted);
                editPhoneNumber.setSelection(formatted.length());

                boolean valid = digits.matches("\\d{10}");
                imageValidPhone.setVisibility(valid ? ImageView.VISIBLE : ImageView.GONE);
                buttonSavePhone.setEnabled(valid);

                isFormatting = false;
            }
        });
    }

    private void setupListeners() {

        buttonSavePhone.setOnClickListener(v -> {
            String digits = editPhoneNumber.getText().toString().replaceAll("\\D", "");

            if (!digits.matches("\\d{10}")) {
                Toast.makeText(this,
                        "Use 10-digit number only. Example: 5405551234",
                        Toast.LENGTH_LONG).show();
                return;
            }

            getSharedPreferences("sms_prefs", MODE_PRIVATE)
                    .edit()
                    .putString("phone_number", digits)
                    .apply();

            Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
        });

        buttonRequestPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_SMS_PERMISSION
                );
            } else {
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            }
        });

        switchEnableSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            notificationsViewModel.setSmsEnabled(isChecked);
            Toast.makeText(
                    this,
                    isChecked ? "SMS alerts enabled" : "SMS alerts disabled",
                    Toast.LENGTH_SHORT
            ).show();
        });

        buttonTestSms.setOnClickListener(v -> {
            if (!notificationsViewModel.isSmsEnabled()) {
                Toast.makeText(
                        this,
                        "SMS alerts are disabled in settings.",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                sendTestSms();

            } else {
                Toast.makeText(
                        this,
                        "SMS permission denied. Cannot send SMS.",
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    private String formatPhone(String digits) {
        if (digits.length() <= 3) return digits;
        if (digits.length() <= 6) return digits.substring(0, 3) + "-" + digits.substring(3);
        return digits.substring(0, 3) + "-" + digits.substring(3, 6) + "-" + digits.substring(6);
    }

    private void sendTestSms() {
        SharedPreferences prefs = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved.", Toast.LENGTH_LONG).show();
            return;
        }

        boolean success = notificationsViewModel.sendSms(
                phoneNumber,
                "Test: Low inventory alert would be sent."
        );

        Toast.makeText(
                this,
                success ? "SMS sent successfully." : "Failed to send SMS.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void updateStatusText() {
        boolean granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        textStatus.setText(granted
                ? "SMS Permission: GRANTED"
                : "SMS Permission: NOT GRANTED");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            boolean granted = grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            Toast.makeText(
                    this,
                    granted
                            ? "SMS permission granted"
                            : "SMS permission denied. App will continue without SMS notifications.",
                    Toast.LENGTH_LONG
            ).show();

            updateStatusText();
        }
    }
}