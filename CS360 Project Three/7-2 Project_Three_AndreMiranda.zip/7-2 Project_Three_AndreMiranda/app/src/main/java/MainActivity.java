package com.example.project_two_andremiranda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ViewModel
        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // UI references
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Disable login button until both fields have text
        buttonLogin.setEnabled(false);

        // Enable login button only when both fields have text
        TextWatcher loginWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String username = editUsername.getText().toString().trim();
                String password = editPassword.getText().toString().trim();
                buttonLogin.setEnabled(!username.isEmpty() && !password.isEmpty());
            }
        };

        editUsername.addTextChangedListener(loginWatcher);
        editPassword.addTextChangedListener(loginWatcher);

        // Observe LOGIN result once
        loginViewModel.getLoginResult().observe(this, success -> {
            if (success == null) return;

            if (success) {
                String username = editUsername.getText().toString().trim();
                Toast.makeText(this, "Welcome " + username, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, InventoryActivity.class));
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // Observe ACCOUNT CREATION result once
        loginViewModel.getAccountCreated().observe(this, success -> {
            if (success == null) return;

            if (success) {
                Toast.makeText(this, "Account created. You may now log in.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            }
        });

        // Login button
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();
            loginViewModel.login(username, password);
        });

        // Create Account button
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Username and password are required", Toast.LENGTH_SHORT).show();
                return;
            }

            loginViewModel.createAccount(username, password);
        });
    }
}