package com.example.project_two_andremiranda;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.project_two_andremiranda.InventoryRepository.RepositoryCallback;

import java.util.List;

public class InventoryViewModel extends AndroidViewModel {

    private final InventoryRepository repository;          // Repository for DB operations
    private final LiveData<List<InventoryItem>> allItems;  // Live list of all items

    // Holds a single item for EditItemActivity
    private final MutableLiveData<InventoryItem> selectedItem = new MutableLiveData<>();

    public InventoryViewModel(@NonNull Application application) {
        super(application);
        repository = new InventoryRepository(application);  // Initialize repository
        allItems = repository.getAllItems();                // Load all items from DB
    }

    // Returns all inventory items (LiveData)
    public LiveData<List<InventoryItem>> getAllItems() {
        return allItems;
    }

    // Returns the selected item (LiveData)
    public LiveData<InventoryItem> getSelectedItem() {
        return selectedItem;
    }

    // Loads a single item by ID asynchronously
    public void loadItemById(int id) {
        repository.getItemById(id, item -> selectedItem.postValue(item));
    }

    // Insert item
    public void insert(InventoryItem item) {
        repository.insert(item);
    }

    // Update item
    public void update(InventoryItem item) {
        repository.update(item);
    }

    // Delete item
    public void delete(InventoryItem item) {
        repository.delete(item);
    }

    // Delete all items
    public void deleteAll() {
        repository.deleteAll();
    }

    // Duplicate name check
    public void checkDuplicateName(String name, RepositoryCallback<Boolean> callback) {
        // Calls repository to check if an item with this name already exists
        repository.checkDuplicateName(name, callback);
    }
}