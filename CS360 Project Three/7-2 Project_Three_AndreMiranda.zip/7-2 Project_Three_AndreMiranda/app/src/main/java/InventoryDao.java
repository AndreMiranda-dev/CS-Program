package com.example.project_two_andremiranda;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {

    // Insert item
    @Insert
    void insert(InventoryItem item);

    // Get all items (LiveData)
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    LiveData<List<InventoryItem>> getAllItems();

    // Get a single item by ID (non-LiveData)
    @Query("SELECT * FROM inventory_items WHERE id = :id LIMIT 1")
    InventoryItem getItemById(int id);

    // Get all zero-stock items
    @Query("SELECT * FROM inventory_items WHERE quantity = 0")
    List<InventoryItem> getZeroStockItems();

    // Update item
    @Update
    void update(InventoryItem item);

    // Delete item
    @Delete
    void delete(InventoryItem item);

    // Delete all items
    @Query("DELETE FROM inventory_items")
    void deleteAll();

    // Duplicate name check
    @Query("SELECT COUNT(*) FROM inventory_items WHERE name = :name")
    int countItemsByName(String name);
}