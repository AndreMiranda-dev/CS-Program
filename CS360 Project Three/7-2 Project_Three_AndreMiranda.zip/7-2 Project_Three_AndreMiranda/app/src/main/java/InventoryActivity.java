package com.example.project_two_andremiranda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

public class InventoryActivity extends AppCompatActivity {

    private static final String LOW_STOCK_WORK_NAME = "low_stock_worker";

    private RecyclerView recyclerInventory;
    private Button buttonAddItem;
    private InventoryAdapter adapter;
    private InventoryViewModel inventoryViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // UI references
        recyclerInventory = findViewById(R.id.recyclerInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);

        // ViewModel
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        // RecyclerView adapter with edit + delete callbacks
        adapter = new InventoryAdapter(
                this::openEditItemScreen,          // Edit item
                item -> inventoryViewModel.delete(item) // Delete item
        );

        // RecyclerView layout
        recyclerInventory.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerInventory.setAdapter(adapter);

        // Observe LiveData from Room
        inventoryViewModel.getAllItems().observe(this, items -> {
            adapter.submitList(items);
        });

        // Add item button
        buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddItemActivity.class);
            startActivity(intent);
        });

        // Notifications button
        Button buttonNotifications = findViewById(R.id.buttonNotifications);
        buttonNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(this, NotificationsActivity.class);
            startActivity(intent);
        });

        // Schedule periodic low-stock checks
        scheduleLowStockWorker();
    }

    // Opens EditItemActivity for the selected item
    private void openEditItemScreen(InventoryItem item) {
        Intent intent = new Intent(this, EditItemActivity.class);
        intent.putExtra("item_id", item.getId());
        intent.putExtra("item_name", item.getName());
        intent.putExtra("item_quantity", item.getQuantity());
        startActivity(intent);
    }

    // Schedules LowStockWorker to run periodically
    private void scheduleLowStockWorker() {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build();

        PeriodicWorkRequest request =
                new PeriodicWorkRequest.Builder(LowStockWorker.class, 15, TimeUnit.MINUTES)
                        .setConstraints(constraints)
                        .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                LOW_STOCK_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
        );
    }
}