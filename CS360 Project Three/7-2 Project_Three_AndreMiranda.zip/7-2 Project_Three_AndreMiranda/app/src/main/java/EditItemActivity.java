package com.example.project_two_andremiranda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQuantity;
    private Button buttonUpdateItem;
    private Button buttonDeleteItem;

    private InventoryViewModel inventoryViewModel;
    private NotificationsRepository notificationsRepository;

    private int itemId = -1;
    private String originalName = ""; // store original name for duplicate check

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        initViewModel();   // Initialize ViewModel and repositories
        initViews();       // Initialize UI components
        loadItemFromIntent(); // Load item data passed from InventoryActivity
        setupListeners();  // Set up button listeners
    }

    private void initViewModel() {
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);
        notificationsRepository = new NotificationsRepository(this);
    }

    private void initViews() {
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        buttonDeleteItem = findViewById(R.id.buttonDeleteItem);
    }

    private void loadItemFromIntent() {
        itemId = getIntent().getIntExtra("item_id", -1);
        originalName = getIntent().getStringExtra("item_name");
        int quantity = getIntent().getIntExtra("item_quantity", 0);

        // Validate incoming data
        if (itemId == -1 || originalName == null) {
            Toast.makeText(this, "Error loading item.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        editItemName.setText(originalName);
        editItemQuantity.setText(String.valueOf(quantity));
    }

    private void setupListeners() {
        buttonUpdateItem.setOnClickListener(v -> updateItem());
        buttonDeleteItem.setOnClickListener(v -> deleteItem());
    }

    private void updateItem() {
        String newName = editItemName.getText().toString().trim();
        String quantityText = editItemQuantity.getText().toString().trim();

        // Validate empty fields
        if (newName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Name and quantity are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prevent whitespace-only names
        if (newName.trim().isEmpty()) {
            Toast.makeText(this, "Item name cannot be blank.", Toast.LENGTH_SHORT).show();
            return;
        }

        int newQuantity;
        try {
            newQuantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prevent negative quantities
        if (newQuantity < 0) {
            Toast.makeText(this, "Quantity cannot be negative.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for duplicate name (but allow keeping the same name)
        inventoryViewModel.checkDuplicateName(newName, isDuplicate -> {
            if (isDuplicate && !newName.equals(originalName)) {
                runOnUiThread(() ->
                        Toast.makeText(this, "Another item already has this name.", Toast.LENGTH_LONG).show()
                );
                return;
            }

            // Create updated item object
            InventoryItem updated = new InventoryItem();
            updated.setId(itemId);
            updated.setName(newName);
            updated.setQuantity(newQuantity);

            // Update item in database
            inventoryViewModel.update(updated);

            // Handle SMS alert if quantity is zero
            handleZeroStockSms(newName, newQuantity);

            runOnUiThread(() ->
                    Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show()
            );

            finish();
        });
    }

    private void handleZeroStockSms(String name, int quantity) {
        // Only send SMS if quantity is zero
        if (quantity != 0) return;

        // Check if SMS notifications are enabled
        if (!notificationsRepository.isSmsEnabled()) return;

        // Check SMS permission
        boolean hasPermission =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (!hasPermission) return;

        // Load saved phone number
        SharedPreferences prefs = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved.", Toast.LENGTH_LONG).show();
            return;
        }

        // Build SMS message
        String message = "ALERT: Inventory item '" + name + "' has reached ZERO stock.";

        // Send SMS
        boolean sent = notificationsRepository.sendSms(phoneNumber, message);

        if (!sent) {
            Toast.makeText(this, "Failed to send SMS alert.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        // Create item object for deletion
        InventoryItem toDelete = new InventoryItem();
        toDelete.setId(itemId);

        // Delete item from database
        inventoryViewModel.delete(toDelete);

        Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
        finish();
    }
}