package com.example.project_two_andremiranda;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class NotificationsViewModel extends AndroidViewModel {

    private final NotificationsRepository repository;

    public NotificationsViewModel(@NonNull Application application) {
        super(application);
        repository = new NotificationsRepository(application);
    }

    // Enable or disable SMS alerts
    public void setSmsEnabled(boolean enabled) {
        repository.setSmsEnabled(enabled);
    }

    // Returns true if SMS alerts are enabled
    public boolean isSmsEnabled() {
        return repository.isSmsEnabled();
    }

    // Sends an SMS message using the repository
    public boolean sendSms(String phoneNumber, String message) {
        return repository.sendSms(phoneNumber, message);
    }
}