package com.example.project_two_andremiranda;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginViewModel extends AndroidViewModel {

    private static final String PREFS_NAME = "login_prefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD_HASH = "password_hash";

    private final MutableLiveData<Boolean> loginResult = new MutableLiveData<>();
    private final MutableLiveData<Boolean> accountCreated = new MutableLiveData<>();

    private final SharedPreferences prefs;

    public LoginViewModel(@NonNull Application application) {
        super(application);
        prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // LiveData Getters
    public LiveData<Boolean> getLoginResult() {
        return loginResult;
    }

    public LiveData<Boolean> getAccountCreated() {
        return accountCreated;
    }

    // Account Creation
    public void createAccount(String username, String password) {
        String existingUser = prefs.getString(KEY_USERNAME, null);

        if (existingUser != null && existingUser.equals(username)) {
            accountCreated.setValue(false);
            return;
        }

        String hashed = hashPassword(password);

        prefs.edit()
                .putString(KEY_USERNAME, username)
                .putString(KEY_PASSWORD_HASH, hashed)
                .apply();

        accountCreated.setValue(true);
    }

    // Login
    public void login(String username, String password) {
        String savedUser = prefs.getString(KEY_USERNAME, null);
        String savedHash = prefs.getString(KEY_PASSWORD_HASH, null);

        if (savedUser == null || savedHash == null) {
            loginResult.setValue(false);
            return;
        }

        boolean match =
                savedUser.equals(username) &&
                        savedHash.equals(hashPassword(password));

        loginResult.setValue(match);
    }

    // Password Hashing
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));

            // Convert bytes → hex string
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();

        } catch (NoSuchAlgorithmException e) {
            // Should never happen on Android
            e.printStackTrace();
            return "";
        }
    }
}