package com.example.project_two_andremiranda;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.List;

public class LowStockWorker extends Worker {

    private final InventoryDao inventoryDao;
    private final NotificationsRepository notificationsRepository;

    public LowStockWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);

        AppDatabase db = AppDatabase.getDatabase(context);
        inventoryDao = db.inventoryDao();

        notificationsRepository = new NotificationsRepository(context);
    }

    @NonNull
    @Override
    public Result doWork() {

        // 1. Respect user preference
        if (!notificationsRepository.isSmsEnabled()) {
            return Result.success();
        }

        // 2. Respect Android permission model
        boolean hasPermission =
                ContextCompat.checkSelfPermission(
                        getApplicationContext(),
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (!hasPermission) {
            // App must not crash or retry endlessly
            return Result.success();
        }

        // 3. Load saved phone number safely
        SharedPreferences prefs = getApplicationContext()
                .getSharedPreferences("sms_prefs", Context.MODE_PRIVATE);

        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return Result.success();
        }

        // 4. Query zero-stock items
        List<InventoryItem> zeroStockItems;
        try {
            zeroStockItems = inventoryDao.getZeroStockItems();
        } catch (Exception e) {
            // Defensive: DB failure should not crash worker
            e.printStackTrace();
            return Result.retry();
        }

        if (zeroStockItems == null || zeroStockItems.isEmpty()) {
            return Result.success();
        }

        // 5. Send SMS for each zero-stock item
        for (InventoryItem item : zeroStockItems) {

            if (item == null || item.getName() == null) {
                continue; // Defensive null-safety
            }

            String message = "ALERT: Inventory item '" + item.getName() + "' has reached ZERO stock.";

            boolean sent = notificationsRepository.sendSms(phoneNumber, message);

            // If SMS fails, do NOT retry the entire worker — avoid SMS spam
            if (!sent) {
                // Log and continue
                System.err.println("Failed to send SMS for item: " + item.getName());
            }
        }

        return Result.success();
    }
}