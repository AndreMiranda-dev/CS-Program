package com.example.project_two_andremiranda;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryAdapter extends ListAdapter<InventoryItem, InventoryAdapter.InventoryViewHolder> {

    // Listener for tapping an item
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    // Listener for delete button
    public interface OnDeleteClickListener {
        void onDeleteClick(InventoryItem item);
    }

    private final OnItemClickListener itemClickListener;
    private final OnDeleteClickListener deleteClickListener;

    public InventoryAdapter(OnItemClickListener itemClickListener,
                            OnDeleteClickListener deleteClickListener) {
        super(DIFF_CALLBACK);
        this.itemClickListener = itemClickListener;
        this.deleteClickListener = deleteClickListener;
    }

    // DiffUtil for efficient RecyclerView updates
    private static final DiffUtil.ItemCallback<InventoryItem> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<InventoryItem>() {
                @Override
                public boolean areItemsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
                    return oldItem.getId() == newItem.getId();
                }

                @Override
                public boolean areContentsTheSame(@NonNull InventoryItem oldItem, @NonNull InventoryItem newItem) {
                    return oldItem.equals(newItem);
                }
            };

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = getItem(position);

        holder.textName.setText(item.getName());
        holder.textQuantity.setText("Qty: " + item.getQuantity());

        // Color indicator based on quantity
        if (item.getQuantity() == 0) {
            holder.textQuantity.setTextColor(Color.RED);
        } else if (item.getQuantity() <= 5) {
            holder.textQuantity.setTextColor(Color.rgb(255, 165, 0)); // Orange
        } else {
            holder.textQuantity.setTextColor(Color.GREEN);
        }

        // Edit item
        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(item);
            }
        });

        // Delete item
        holder.buttonDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(item);
            }
        });
    }

    // ViewHolder for each inventory row
    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView textName;
        TextView textQuantity;
        ImageButton buttonDelete;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textItemName);
            textQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteRow);
        }
    }
}