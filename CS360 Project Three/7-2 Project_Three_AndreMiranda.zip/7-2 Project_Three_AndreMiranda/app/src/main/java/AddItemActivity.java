package com.example.project_two_andremiranda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQuantity;
    private Button buttonSaveItem;
    private Button buttonCancelAdd;

    private InventoryViewModel inventoryViewModel;
    private NotificationsRepository notificationsRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        initViewModel();   // Initialize ViewModel and repositories
        initViews();       // Initialize UI components
        setupListeners();  // Set up button listeners
    }

    private void initViewModel() {
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);
        notificationsRepository = new NotificationsRepository(this);
    }

    private void initViews() {
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonCancelAdd = findViewById(R.id.buttonCancelAdd);
    }

    private void setupListeners() {
        buttonSaveItem.setOnClickListener(v -> saveItem());
        buttonCancelAdd.setOnClickListener(v -> finish());
    }

    private void saveItem() {
        String name = editItemName.getText().toString().trim();
        String quantityText = editItemQuantity.getText().toString().trim();

        // Validate empty fields
        if (name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Name and quantity are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prevent whitespace-only names
        if (name.trim().isEmpty()) {
            Toast.makeText(this, "Item name cannot be blank.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prevent negative quantities
        if (quantity < 0) {
            Toast.makeText(this, "Quantity cannot be negative.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for duplicate item names before inserting
        inventoryViewModel.checkDuplicateName(name, isDuplicate -> {
            if (isDuplicate) {
                runOnUiThread(() ->
                        Toast.makeText(this, "An item with this name already exists.", Toast.LENGTH_LONG).show()
                );
                return;
            }

            // Create item object
            InventoryItem item = new InventoryItem();
            item.setName(name);
            item.setQuantity(quantity);

            // Insert item into database
            inventoryViewModel.insert(item);

            // Handle SMS alert if quantity is zero
            handleZeroStockSms(name, quantity);

            runOnUiThread(() ->
                    Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show()
            );

            finish();
        });
    }

    private void handleZeroStockSms(String name, int quantity) {
        // Only send SMS if quantity is zero
        if (quantity != 0) return;

        // Check if SMS notifications are enabled
        if (!notificationsRepository.isSmsEnabled()) return;

        // Check SMS permission
        boolean hasPermission =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (!hasPermission) return;

        // Load saved phone number
        SharedPreferences prefs = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved.", Toast.LENGTH_LONG).show();
            return;
        }

        // Build SMS message
        String message = "ALERT: Inventory item '" + name + "' has been added with ZERO stock.";

        // Send SMS
        boolean sent = notificationsRepository.sendSms(phoneNumber, message);

        if (!sent) {
            Toast.makeText(this, "Failed to send SMS alert.", Toast.LENGTH_SHORT).show();
        }
    }
}