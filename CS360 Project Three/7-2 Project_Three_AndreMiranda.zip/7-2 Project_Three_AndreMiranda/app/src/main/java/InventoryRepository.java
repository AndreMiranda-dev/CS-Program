package com.example.project_two_andremiranda;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryRepository {

    private final InventoryDao inventoryDao;                 // DAO for database operations
    private final LiveData<List<InventoryItem>> allItems;    // Live list of all items

    // Background thread for DB operations
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public InventoryRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);  // Get database instance
        inventoryDao = db.inventoryDao();                      // Get DAO
        allItems = inventoryDao.getAllItems();                 // Load all items
    }

    // Read all items (LiveData)
    public LiveData<List<InventoryItem>> getAllItems() {
        return allItems;
    }

    // Read a single item by ID (async callback)
    public void getItemById(int id, RepositoryCallback<InventoryItem> callback) {
        executorService.execute(() -> {
            InventoryItem item = inventoryDao.getItemById(id);
            callback.onComplete(item);
        });
    }

    // Insert item
    public void insert(InventoryItem item) {
        executorService.execute(() -> inventoryDao.insert(item));
    }

    // Update item
    public void update(InventoryItem item) {
        executorService.execute(() -> inventoryDao.update(item));
    }

    // Delete item
    public void delete(InventoryItem item) {
        executorService.execute(() -> inventoryDao.delete(item));
    }

    // Delete all items
    public void deleteAll() {
        executorService.execute(inventoryDao::deleteAll);
    }

    // Duplicate name check
    public void checkDuplicateName(String name, RepositoryCallback<Boolean> callback) {
        executorService.execute(() -> {
            int count = inventoryDao.countItemsByName(name);   // Query DB for duplicates
            callback.onComplete(count > 0);                    // Return true if duplicate exists
        });
    }

    // Callback interface for async queries
    public interface RepositoryCallback<T> {
        void onComplete(T result);
    }
}